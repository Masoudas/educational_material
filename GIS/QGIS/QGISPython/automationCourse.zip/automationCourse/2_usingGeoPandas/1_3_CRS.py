"""
CRS: Coordinate reference systems define how coordinates relate to real locations on the Earth. Geographic coordinate reference systems commonly use latitude and longitude degrees. Projected coordinate reference systems use x and y coordinates to represent locations on a flat surface. You will learn more about coordinate reference systems during this lesson!
"""