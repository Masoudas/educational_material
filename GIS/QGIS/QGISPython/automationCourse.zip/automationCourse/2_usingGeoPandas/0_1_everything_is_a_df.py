"""
Recall that with pandas, whatever we get as the result of manipulating a dataframe, is another dataframe. For example, if we got row one, we get another df. If we get column 1, another one. If we apply some mapper, another one, etc.
"""
import geopandas as gpd
