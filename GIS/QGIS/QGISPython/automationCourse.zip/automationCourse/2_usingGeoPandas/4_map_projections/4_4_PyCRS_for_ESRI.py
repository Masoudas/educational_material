"""
Note that we the PyCRS module contains references to other coordinate systems such as OGC WKT (v1), ESRI WKT, Proj4, and any EPSG, ESRI, or SR-ORG code available from spatialreference.org.
"""