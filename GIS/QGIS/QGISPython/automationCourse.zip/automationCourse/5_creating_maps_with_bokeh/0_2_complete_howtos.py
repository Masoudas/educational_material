"""
This github page contains multiple examples on several features.

https://github.com/bokeh/bokeh/tree/2.4.2/examples/howto
"""
